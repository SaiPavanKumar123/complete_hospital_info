package com.insurance.Hospital.contractors;

import java.util.ArrayList;
import java.util.List;

import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.PolicyMembers;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.Uploads;

import jakarta.servlet.http.HttpServletResponse;

public interface ClaimServiceInterface {
	
	// ListClaims

		ArrayList<Claim> getAllClaims();

		ArrayList<Claim> getFilteredClaims(String status);

		Claim getClaimById(int clamId);

		//New Claim

		void addClaimApplication(ClaimApplication application);

		void addClaim(int clamIplcId, double requestAmount, String hospname);

		Claim getClaimByid(int clamIplcId);

		void addClaimBills(ClaimBills bill);

		List<String> getFamilyByPolicy(int id);

		// Upload

		

		List<ReUpload> getAllReUploads(int id);

		void addUploads(Uploads up);

		List<Uploads> getAllUploads(int claimId);

		void updateReUploads(int reuploadId,int claimId);

		boolean checkPolicyIdStatus(int policyId);

		void downloadExcel(String status, HttpServletResponse response);

		boolean checkRequestedAmount(int clamIplcId, double claimAmountRequested);

		
}
