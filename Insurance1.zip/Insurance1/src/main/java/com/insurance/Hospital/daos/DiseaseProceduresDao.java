package com.insurance.Hospital.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.Hospital.contractors.DiseaseProceduresDaoInterface;
import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.DiseaseProcedures;
import com.insurance.Hospital.rowmappers.*;

@Component
public class DiseaseProceduresDao implements DiseaseProceduresDaoInterface {

	private final JdbcTemplate jdbcTemplate;

	@Autowired(required = true)
	public DiseaseProceduresDao(JdbcTemplate jdbcTemplate) {

		this.jdbcTemplate = jdbcTemplate;
	}

	private static final String GET_DISEASE_DETAILS = "Select * from diseases";
	String GET_PROCEDURES_BY_DIS_ID = "Select * from proceduress where proc_disc_id=?";

	@Override
	public List<DiseaseProcedures> getProceduresByDisId(int diseaseId) {
		return jdbcTemplate.query(GET_PROCEDURES_BY_DIS_ID, new Object[] { diseaseId }, new DiseaseProceduresRowMapper());
	}
}
