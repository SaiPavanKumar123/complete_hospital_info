package com.insurance.Hospital.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.DiseaseProcedures;
import com.insurance.Hospital.contractors.DiseaseProceduresServiceInterface;

@Controller
public class ProceduresController {

    private static final Logger logger = LoggerFactory.getLogger(ProceduresController.class);

    @Autowired(required = true)
    DiseaseProceduresServiceInterface disc;

    // To get procedures based on diseaseId
    @GetMapping(value = "/procedures/{diseaseId}")
    public String getProceduresByDisId(@PathVariable String diseaseId, Model model) {
        try {
            logger.info("Fetching procedures for disease ID: {}", diseaseId);
            List<DiseaseProcedures> procedures = disc.getProceduresByDisId(Integer.parseInt(diseaseId));
            logger.info("Procedures retrieved successfully.");
            logger.debug("Procedures: {}", procedures);
            model.addAttribute("procedures", procedures);
            return "diseaseProcedures";
        } catch (Exception e) {
            logger.error("Error occurred while fetching procedures: {}", e.getMessage());
            // Handle the exception and return an appropriate view or message
            return "errorPage";
        }
    }
}
