package com.insurance.Hospital.contractors;

import com.insurance.Hospital.models.LoginClass;

public interface LoginDaoInterface {

	int sendmail(String to_mail);
	
	int checkCredentials(LoginClass lc);

	int resetpwd(String email, String pwd);
}
