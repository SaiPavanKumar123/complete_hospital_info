package com.insurance.Hospital.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.contractors.PaymentDaoInterface;
import com.insurance.Hospital.contractors.PaymentsServiceInterface;
import com.insurance.Hospital.models.Payments;

@Service
public class PaymentsService implements PaymentsServiceInterface {
	
	@Autowired
	PaymentDaoInterface paymentDaoInterface;

	@Override
	public List<Payments> getPayments() {

		return paymentDaoInterface.getPayments();
	}

	@Override
	public Payments getPaymentById(int paymentId) {
		return paymentDaoInterface.getPaymentById(paymentId);
	}

	@Override
	public List<Payments> filterList(String type, String value) {
		return paymentDaoInterface.filterList(type, value);
	}
	
}
