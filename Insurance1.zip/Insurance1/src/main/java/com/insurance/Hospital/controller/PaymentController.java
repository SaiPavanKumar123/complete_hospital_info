package com.insurance.Hospital.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.insurance.Hospital.contractors.PaymentsServiceInterface;
import com.insurance.Hospital.models.Payments;

import jakarta.servlet.http.HttpSession;

@Controller
public class PaymentController {

	PaymentsServiceInterface paymentsServiceInterface;
	
	Logger logger = LoggerFactory.getLogger(PaymentsServiceInterface.class);


	@Autowired
	public PaymentController(PaymentsServiceInterface paymentsServiceInterface, HttpSession httpSession) {
		this.paymentsServiceInterface = paymentsServiceInterface;
	}
	
	
	//To List all payments 
	@GetMapping("/payments")
	public String displayPayments(Model model) {
	    try {
	        // Get all payments
	        List<Payments> payments = paymentsServiceInterface.getPayments();
	        model.addAttribute("payments", payments);
	        
	        // Log a message indicating successful retrieval of payments
	        logger.info("Retrieved {} payments.", payments.size());
	        
	        return "payments";
	    } catch (Exception e) {
	        // Log any exceptions that occur during the process
	        logger.error("Error occurred while retrieving payments: {}", e.getMessage());
	        // Handle the exception or return an error view if necessary
	        throw e;
	    }
	}
	
	
	//To view Payment details
	@GetMapping("/view")
	public String viewPayment(@RequestParam("id") String settlementId, Model model) {
		 try {
		        int paymentId = Integer.parseInt(settlementId);
		        // Log the payment ID being processed
		        logger.info("Viewing payment details for ID: {}", paymentId);
		        
		        // Get Payment by id
		        Payments payment = paymentsServiceInterface.getPaymentById(paymentId);
		        model.addAttribute("payment", payment);
		        
		        return "paymentDetails";
		    } catch (NumberFormatException e) {
		        // Log invalid input and return an error view or handle it as needed
		        logger.error("Invalid payment ID provided: {}", settlementId);
		       throw e;
		    } catch (Exception e) {
		        // Log any other exceptions that occur during the process
		        logger.error("Error occurred while viewing payment details: {}", e.getMessage());
		        // Handle the exception or return an error view if necessary
		        throw e;
		    }
	}
	//to filter payments by server side
	@GetMapping("/search")
	public String searchPaymentsByPaymentId(@RequestParam("filterBy") String type, @RequestParam("value") String value,
			Model model) {
		 try {
	            // Log the filter criteria and value being used
	            logger.info("Searching payments by {} with value: {}", type, value);
	            
	            // Get filtered Payments
	            List<Payments> filteredData = paymentsServiceInterface.filterList(type, value);
	            model.addAttribute("payments", filteredData);
	            
	            return "payments";
	        } catch (Exception e) {
	            // Log the error and handle it gracefully
	            logger.error("Error occurred while searching payments: {}", e.getMessage(), e);
	            // You might want to add a custom error message to the model and return an error page.
	            throw e;
	        }
	}
}
