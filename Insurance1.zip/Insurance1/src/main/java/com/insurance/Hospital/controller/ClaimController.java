package com.insurance.Hospital.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Hospital.contractors.ClaimServiceInterface;
import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.NonActivePolicyException;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.RequestedAmountException;
import com.insurance.Hospital.models.Uploads;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class ClaimController {

    private static final Logger logger = LoggerFactory.getLogger(ClaimController.class);
    
    ClaimServiceInterface claimServiceInterface;
    private HttpSession httpSession;

    @Autowired
    public ClaimController(ClaimServiceInterface claimServiceInterface, HttpSession httpSession) {
        this.claimServiceInterface = claimServiceInterface;
        this.httpSession = httpSession;
    }

    @GetMapping(value = "/newclaim")
    public String newClaim(Model model) {
        logger.trace("Navigating to the new claim page.");
        return "SETCLAIMS";
    }

    @RequestMapping(value = "/claimbills", method = RequestMethod.POST)
    public String claimData(@RequestParam("file[]") MultipartFile[] files,
                            @RequestParam("documentTitle") String[] documentNames,
                            @RequestParam("claimAmount") String[] claimAmount,
                            Claim claim, ClaimApplication application, Model model) {
        try {
            int policyId = claim.getClamIplcId();
            logger.trace("Checking policy status for policy ID: {}", policyId);
            if (claimServiceInterface.checkPolicyIdStatus(policyId)) {
                throw new NonActivePolicyException("Invalid policy details provided.");
            }

            if (!claimServiceInterface.checkRequestedAmount(application.getClamIplcId(),
                    application.getClaimAmountRequested())) {
                throw new RequestedAmountException("Requested amount cannot be granted", "REQAMT001");
            }

            claimServiceInterface.addClaimApplication(application);
            claimServiceInterface.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested(),
                    "IMS Hospital");

            Claim clm_id = claimServiceInterface.getClaimByid(claim.getClamIplcId());
            int cid = clm_id.getClamId();
            String uploadDir = "src/main/resources/static/file";

            try {
                Files.createDirectories(Paths.get(uploadDir));
                int i = 0;
                for (MultipartFile file : files) {
                    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                    Path targetLocation = Paths.get(uploadDir).resolve(fileName);
                    Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                    String fullPath = targetLocation.toAbsolutePath().toString();
                    ClaimBills bill = new ClaimBills();
                    bill.setClbl_document_path(fileName);
                    bill.setClbl_document_path(documentNames[i]);
                    bill.setClbl_claim_amount(Double.parseDouble(claimAmount[i]));
                    bill.setClam_id(cid);
                    claimServiceInterface.addClaimBills(bill);
                }
            } catch (IOException ex) {
                logger.error("Error occurred while processing claim bills: {}", ex.getMessage());
            }

        } catch (NonActivePolicyException ex) {
            logger.error("Non-active policy detected: {}", ex.getMessage());
            model.addAttribute("errorMessage",
                    "Policy is not in active status, so you cannot claim with the provided details.");
            return "exception";
        } catch (RequestedAmountException ex) {
            logger.error("Requested amount cannot be granted: {}", ex.getMessage());
            model.addAttribute("errorCode", ex.getErrorCode());
            model.addAttribute("errorMessage", ex.getMsg());
            return "errorPage";
        } catch (Exception ex) {
            logger.error("An error occurred while processing claim data: {}", ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
        return "SETCLAIMS";
    }

    @GetMapping(value = "/getFamilyMembers")
    public ResponseEntity<List<String>> getFamily(@RequestParam("policy") int id, Model model) {
        try {
            List<String> members = claimServiceInterface.getFamilyByPolicy(id);
            logger.info("Retrieved family members for policy ID: {}", id);
            return ResponseEntity.ok(members);
        } catch (Exception ex) {
            logger.error("Error occurred while retrieving family members: {}", ex.getMessage());
            return ResponseEntity.status(500).body(new ArrayList<>());
        }
    }

    @GetMapping(value = "/getAllClaims")
    public String getAllClaims(Model model) {
        try {
            ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getAllClaims();
            logger.info("Retrieved all claims. Total claims: {}", li.size());
            model.addAttribute("claims", li);
            return "listclaims";
        } catch (Exception ex) {
            logger.error("Error occurred while retrieving all claims: {}", ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
    }

    @PostMapping(value = "/viewClaim")
    public String getClaimById(Model model, @RequestParam("clamId") int clamId) {
        try {
            Claim cl = claimServiceInterface.getClaimById(clamId);
            logger.info("Retrieved claim by ID: {}", clamId);
            model.addAttribute("claim", cl);
            return "viewclaim";
        } catch (Exception ex) {
            logger.error("Error occurred while retrieving claim by ID {}: {}", clamId, ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
    }

    @GetMapping(value = "/getFilteredClaims")
    public String getFilteredClaims(Model model, @RequestParam("status") String status) {
        try {
            ArrayList<Claim> li = (ArrayList<Claim>) claimServiceInterface.getFilteredClaims(status);
            logger.info("Retrieved filtered claims by status {}. Total claims: {}", status, li.size());
            model.addAttribute("claims", li);
            return "listclaims";
        } catch (Exception ex) {
            logger.error("Error occurred while retrieving filtered claims by status {}: {}", status, ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
    }

    @RequestMapping(value = "/excel", method = RequestMethod.POST)
    public void downloadExcel(@RequestParam("selectedStatus") String status, HttpServletResponse response)
            throws IOException {
        try {
            claimServiceInterface.downloadExcel(status, response);
            logger.info("Downloaded Excel file for claims with status: {}", status);
        } catch (Exception ex) {
            logger.error("Error occurred while downloading Excel file for claims with status {}: {}", status, ex.getMessage());
            // Handle the exception and possibly return an error response to the client.
        }
    }

    @GetMapping(value = "/getrequired")
    public String getRequiredUploads(@RequestParam("claimid") int id, Model model) {
        try {
            if (!claimServiceInterface.getAllReUploads(id).isEmpty()) {
                model.addAttribute("reupload", claimServiceInterface.getAllReUploads(id));
                model.addAttribute("claimid", id);
                logger.info("Retrieved required uploads for claim ID: {}", id);
                return "update";
            } else {
                model.addAttribute("claimid", id);
                logger.info("No required uploads found for claim ID: {}", id);
                return "status";
            }
        } catch (Exception ex) {
            logger.error("Error occurred while retrieving required uploads for claim ID {}: {}", id, ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
    }

    @PostMapping(value = "/adduploads")
    public String addUploads(@RequestParam("claimid") String id, MultipartHttpServletRequest request, Model model) {
        try {
            int claimId = Integer.parseInt(id);
            int index = 1;
            List<ReUpload> list = claimServiceInterface.getAllReUploads(claimId);
            List<Uploads> list2 = claimServiceInterface.getAllUploads(claimId);

            if (list2.size() > 0) {
                index = list2.get(list2.size()).getReUploadId();
            }

            for (ReUpload upload : list) {
                if (upload.getClaimId() == claimId) {
                    String name = upload.getName();
                    MultipartFile file = request.getFile(name);
                    if (file != null) {
                        String uploadDir = "src/main/resources/static/file";
                        Files.createDirectories(Paths.get(uploadDir));
                        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
                        Path targetLocation = Paths.get(uploadDir).resolve(fileName);
                        Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                        String fullPath = targetLocation.toAbsolutePath().toString();
                        Uploads up = new Uploads();
                        up.setUploadId(index);
                        up.setReUploadId(upload.getUploadId());
                        up.setClaimId(claimId);
                        up.setData(fullPath);
                        up.setType("file");
                        claimServiceInterface.addUploads(up);
                        claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);
                    } else {
                        Uploads up = new Uploads();
                        up.setUploadId(index);
                        up.setReUploadId(upload.getUploadId());
                        up.setClaimId(claimId);
                        up.setData(request.getParameter(name));
                        up.setType("text");
                        claimServiceInterface.addUploads(up);
                        claimServiceInterface.updateReUploads(upload.getUploadId(), claimId);
                    }
                }
            }
            model.addAttribute("claimid", claimId);
            logger.info("Uploaded files for claim ID: {}", claimId);
            return "viewclaim";
        } catch (Exception ex) {
            logger.error("Error occurred while adding uploads for claim ID {}: {}", id, ex.getMessage());
            model.addAttribute("errorMessage", "An error occurred while processing your request.");
            return "errorPage";
        }
    }
}
