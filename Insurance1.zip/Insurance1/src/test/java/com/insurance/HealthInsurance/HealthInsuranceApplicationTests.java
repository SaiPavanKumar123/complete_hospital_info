package com.insurance.HealthInsurance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthInsuranceApplicationTests {

	@Test
	void contextLoads() {
	}

}
